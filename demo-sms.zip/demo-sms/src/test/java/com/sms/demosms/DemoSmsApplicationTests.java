package com.sms.demosms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
