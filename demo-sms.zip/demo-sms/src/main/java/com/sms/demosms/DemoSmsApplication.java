package com.sms.demosms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSmsApplication.class, args);
	}

}
